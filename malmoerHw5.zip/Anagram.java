//Ryan Malmoe | Prof: Tom Capaul | CSCD300 12:00

import java.lang.Math.*;
import java.util.*;
import java.lang.*;


public class Anagram
{

   protected String word = ""; //Regular word
   protected String wordSorted = ""; //Key
   
   public String getWord()
   {
      return this.word;
   }
   
   public String getWordSorted()
   {
      return this.wordSorted;
   }

}